/*
 *require('../models/coin');
 *require('../models/walletAddress');
 *require('../models/transaction');
 *require('../models/wallet');
 *require('../models/block');
 *
 */
