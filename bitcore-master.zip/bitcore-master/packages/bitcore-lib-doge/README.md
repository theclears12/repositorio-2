Bitcore lib for doge. See bitcore-lib-litecoin for details.
=======