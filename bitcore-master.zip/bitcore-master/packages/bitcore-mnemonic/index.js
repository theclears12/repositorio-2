module.exports = require('./lib/mnemonic');
